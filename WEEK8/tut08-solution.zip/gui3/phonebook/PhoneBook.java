package tutes.gui3.phonebook;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class PhoneBook extends WindowAdapter implements ActionListener {
    private JFrame gui;
    private AddContact addGUI;
    private JTable tblContacts;

    public PhoneBook() {
        createGUI();
    }

    private void createGUI() {
        gui = new JFrame("Phone Book");
        gui.setSize(300, 300);
        gui.addWindowListener(this);

        // center panel
        JPanel pnlMiddle = new JPanel();
        pnlMiddle.setLayout(new BorderLayout());
        gui.add(pnlMiddle);

        String[] headers = {"Name", "Phone"};
        Object[][] data = {
                {"Vu Minh Tuan", "0982609010"},
                {"Dang Dinh Quan", "0982496005"},
        };

        DefaultTableModel tm = new DefaultTableModel(data, headers);
        tblContacts = new JTable(tm);
        JScrollPane scrContacts = new JScrollPane(tblContacts);
        pnlMiddle.add(scrContacts);

        // bottom
        JPanel pnlBottom = new JPanel();
        gui.add(pnlBottom, BorderLayout.SOUTH);

        JButton btnAdd = new JButton("Add Contact");
        btnAdd.addActionListener(this);
        pnlBottom.add(btnAdd);

        gui.setLocationRelativeTo(null);
    }

    public void display() {
        gui.setVisible(true);
    }

    @Override
    public void windowClosing(WindowEvent e) {
        shutDown();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if (command.equals("Add Contact")) {
            if (addGUI == null) addGUI = new AddContact(gui, this);
            addGUI.display();
        }
    }

    private void shutDown() {
        System.exit(0);
    }

    public void addContact(String name, String phone) {
        DefaultTableModel model = (DefaultTableModel) tblContacts.getModel();
        model.addRow(new String[]{name, phone});
    }

    public static void main(String[] args) {
        PhoneBook app = new PhoneBook();
        app.display();
    }
}
