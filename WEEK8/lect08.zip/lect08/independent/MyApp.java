package lect08.independent;

/**
 * @overview
 *  Represents a standard desktop GUI
 *
 * @author dmle
 */
public class MyApp {

    private Controller c;

    private Gui g;

    /**
     * @effects
     *  initialise <tt>c</tt> and invoke <tt>c.displayGUI()</tt>
     */
    public MyApp() {
        c = new Controller();
        g = new Gui(c);
        c.setGui(g);
    }

    /**
     * @effects show window <tt>g</tt>
     */
    public void display() {
        g.display();
    }

    /**
     * The run method
     * @effects
     *  create an instance of <tt>MyApp</tt>
     */
    public static void main(String[] args) {
        MyApp app = new MyApp();
        app.display();
    }
}
