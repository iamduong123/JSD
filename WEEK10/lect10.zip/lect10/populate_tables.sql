INSERT INTO SUPPLIER VALUES(
    49,  'Superior Coffee',
    '1 Party Place', 'Mendocino',
    'CA', '95460'
);


INSERT INTO SUPPLIER VALUES(101, 'Acme, Inc.', '99 Market Street', 'Groundsville', 'CA', '95199'); 
INSERT INTO SUPPLIER VALUES(150, 'The High Ground', '100 Coffee Lane', 'Meadows', 'CA', '93966'); 
INSERT INTO SUPPLIER VALUES(456, 'Restaurant Supplies, Inc.', '200 Magnolia Street', 'Meadows', 'CA', '93966'); 
INSERT INTO SUPPLIER VALUES(927, 'Professional Kitchen', '300 Daisy Avenue', 'Groundsville', 'CA', '95199'); 

INSERT INTO COFFEE
VALUES('Colombian', 101, 7.99, 0, 0);

INSERT INTO COFFEE VALUES('French_Roast',       49, 8.99, 0, 0); 
INSERT INTO COFFEE VALUES('Espresso',           150, 9.99, 0, 0); 
INSERT INTO COFFEE VALUES('Colombian_Decaf',    101, 8.99, 0, 0); 
INSERT INTO COFFEE VALUES('French_Roast_Decaf', 049, 9.99, 0, 0);