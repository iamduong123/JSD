package lect05.ano;

public class NotPossibleException extends Exception {
    public NotPossibleException(String message) {
        super(message);
    }
}
