package lect05.meta;

import lect05.app.Course;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Demo {
    public static <R, T> R someMethod(T value, String addition) {
        String s = value.toString() + addition;
        return (R) s;
    }

    public static void main(String[] args) {
        String out = Demo.<String, Integer>someMethod(15, "x");
        System.out.println(out);
    }


}
