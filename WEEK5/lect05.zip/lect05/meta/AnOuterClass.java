package lect05.meta;

public class AnOuterClass {
    private class InnerClass1 {

    }
}

class Class1 {

}

class Class2 {

}