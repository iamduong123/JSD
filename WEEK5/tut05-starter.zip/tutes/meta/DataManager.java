package tutes.meta;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * A class responsible for capturing data for a Pizza application.
 */
public class DataManager {
    public DataManager() {

    }

    private static boolean isDecendant(Class<?> c1, Class<?> c2) {
        Class<?> sup = c1.getSuperclass();

        if (sup == null)
            return false;

        if (sup == c2) {
            return true;
        } else if (sup != Object.class) {
            return isDecendant(sup, c2);
        } else {
            return false;
        }
    }

    // validate attribute values and if ok then create a new instance of c
    public static Object newInstance(Class<?> c, Object[] attributeVals)
            throws NotPossibleException {

        Object o = null;
        try {

            // create a new object using the default constructor method
            Constructor<?>[] cons = c.getDeclaredConstructors();

            // find the constructor that has the same signature as the attributes
            // specified in values
            Constructor<?> co = null;
            Class<?>[] paramTypes;
            for (Constructor<?> con : cons) {
                co = con;
                paramTypes = co.getParameterTypes();
                if (paramTypes.length == attributeVals.length) {
                    boolean match = true;
                    for (int k = 0; k < paramTypes.length; k++) {
                        Class<?> type = paramTypes[k];
                        Object obj = attributeVals[k];
                        // compare the object type with the parameter type
                        if (obj == null)
                            continue; // consider a match
                        Class<?> oc = obj.getClass();
                        if (!type.equals(oc) && !isDecendant(oc, type)) {
                            match = false;
                            break;
                        }
                    }
                    if (match) {
                        // found the constructor
                        break;
                    }
                }
                co = null;
            }

            if (co == null) {
                throw new NotPossibleException(
                        "DataManager.newInstance: could not find constructor matching the data values");
            }

            // System.out.println("constructor: " + co);
            // create a new object
            o = co.newInstance(attributeVals);
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException e) {
            // e.printStackTrace();
            throw new NotPossibleException(
                    "DataManager.newInstance: failed to create a new instance for class: "
                            + c.getName());
        }

        return o;
    }
}
