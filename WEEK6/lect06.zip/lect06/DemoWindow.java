package lect06;

public class DemoWindow {
    public static void main(String[] args) {
        // create a window
        FirstWindow w = new FirstWindow();

        // display it
        w.setVisible(true);
    }
}
