package lect06;

/**
 * This program demonstrates how Model can
 * notify View to update when Model's data is modified
 */
public class PropertyChangeDemo {
    public static void main(String[] args) {
        new DisplayWindow("Demo");
    }
}
