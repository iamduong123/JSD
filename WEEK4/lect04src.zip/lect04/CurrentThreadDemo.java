package lect04;

public class CurrentThreadDemo {

}
