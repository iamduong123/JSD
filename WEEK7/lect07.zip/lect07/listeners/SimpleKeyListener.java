package lect07.listeners;

import java.awt.Component;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JLabel;
import javax.swing.text.JTextComponent;

public class SimpleKeyListener extends KeyAdapter {
    public void keyPressed(KeyEvent e) {
        Component source = (Component) e.getSource();
        String name = null;
        if (source instanceof JTextComponent) {
            name = ((JTextComponent) source).getText();
        } else if (source instanceof JLabel) {
            name = ((JLabel) source).getText();
        } else {
            name = source.getName();
        }

        String type = source.getClass().getSimpleName();
        char key = e.getKeyChar();

        System.out.println("Key pressed on " + type + "(" + name + ")" + ": " + key);
    }
}