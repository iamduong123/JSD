package a2_2101040039;
import a2_2101040039.common.PatronType;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Patron {
    private static List<String> patronIDList = new ArrayList<>();
    private static int idCounter = 1;
    private String id;
    private int idNum;
    private String name;
    private Date dateOfBirth;
    private String email;
    private String phoneNumber;
    private PatronType patronType;

    public Patron(String name, Date dateOfBirth, String email, String phoneNumber, PatronType patronType, int idNum) {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.patronType = patronType;
        this.id = generatePatronID(idNum);
    }
    public PatronType getPatronType() {
        return patronType;
    }

    public String generatePatronID(int idNum) {
        StringBuilder stbID = new StringBuilder();
        String idNumber = String.format("%03d", idNum);
        return String.valueOf(stbID.append("P").append(idNumber));
    }

    public String getId() {
        return id;
    }
    public int getIdNumber() {
        return Integer.parseInt(this.getId().replaceFirst("^[P0]*", ""));
    }

    @Override
    public String toString() {
        return name + " (" + id + ")";
    }
}
