package a2_2101040039;
import a2_2101040039.GUI.LibraryMenu;

public class LibraryManProg {
    public static void main(String[] args) {
        LibraryMenu libraryMenu = new LibraryMenu();
        libraryMenu.display();
    }
}
