package a2_2101040039.common;

public enum PatronType {
    REGULAR,
    PREMIUM
}
