package a2_2101040039;

import a2_2101040039.common.Genre;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Book {
    private String ISBN;
    private String title;
    private String author;
    private Genre genre;
    private int year;
    private int numCopiesAvailable;

    public Book(String title, String author, Genre genre, int year, int numCopiesAvailable) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.year = year;
        this.numCopiesAvailable = numCopiesAvailable;
        this.ISBN = generateISBN();

    }

    public String generateISBN() {
        StringBuilder stbISBN = new StringBuilder();
        Pattern pattern = Pattern.compile("\\b[a-zA-Z]");
        Matcher match = pattern.matcher(getAuthor());
        while (match.find()) {
            stbISBN.append(match.group());
        }
        switch (genre) {
            case FICTION:
                stbISBN.append("-01-");
                break;
            case NON_FICTION:
                stbISBN.append("-02-");
                break;
            case MYSTERY:
                stbISBN.append("-03-");
                break;
            case ROMANCE:
                stbISBN.append("-04-");
                break;
            case SCIENCE_FICTION:
                stbISBN.append("-05-");
                break;
            case FANTASY:
                stbISBN.append("-06-");
                break;
            case THRILLER:
                stbISBN.append("-07-");
                break;
            case BIOGRAPHY:
                stbISBN.append("-08-");
                break;
            case HISTORY:
                stbISBN.append("-09-");
                break;
            case SELF_HELP:
                stbISBN.append("-10-");
                break;
            case HORROR:
                stbISBN.append("-11-");
                break;
            case ADVENTURE:
                stbISBN.append("-12-");
                break;
            case POETRY:
                stbISBN.append("-13-");
                break;
        }
        stbISBN.append(this.year);
        return stbISBN.toString();
    }

    public String getTitle() {
        return title;
    }

    public String getISBN() {
        return this.ISBN;
    }

    public String getAuthor() {
        return author;
    }

    public Genre getGenre() {
        return genre;
    }

    public int getYear() {
        return year;
    }

    public int getNumCopiesAvailable() {
        return numCopiesAvailable;
    }
    public void setNumCopiesAvailable(int num) {
        this.numCopiesAvailable = num;
    }
}
