package a2_2101040039.GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.sql.*;
import java.util.ArrayList;

public class ListPatronWindow extends WindowAdapter implements ActionListener {
    private JFrame gui;
    private JFrame parentGUI;
    private ArrayList<Integer> ids;
    private JTable patronTbl;
    private Statement stmt;
    private Connection connection;


    public ListPatronWindow(JFrame parentGUI, Statement stmt) {
        this.stmt = stmt;
        this.parentGUI = parentGUI;
        createGUI(reloadTable());
    }
    private void createGUI(JTable patronTbl) {
        gui = new JFrame("Patron List");
        gui.setSize(900,600);
        gui.addWindowListener(this);
        JScrollPane scrPatron = new JScrollPane(patronTbl);
        gui.add(scrPatron);
    }
    private JTable reloadTable() {
        DefaultTableModel tableModel = null;
        if(patronTbl == null) {
            String[] headers = {"ID", "Name", "DOB", "Email", "Phone", "Patron Type"};
            Object[][] data = new Object[0][6];
            tableModel = new DefaultTableModel(data, headers);
            patronTbl = new JTable(tableModel);
            patronTbl.getColumnModel().getColumn(0).setPreferredWidth(50);
            patronTbl.getColumnModel().getColumn(1).setPreferredWidth(200);
            patronTbl.getColumnModel().getColumn(2).setPreferredWidth(150);
            patronTbl.getColumnModel().getColumn(3).setPreferredWidth(300);
            patronTbl.getColumnModel().getColumn(4).setPreferredWidth(150);
            patronTbl.getColumnModel().getColumn(5).setPreferredWidth(120);
        } else {
            tableModel = (DefaultTableModel) patronTbl.getModel();
            for (int i = tableModel.getRowCount()-1; i >=0; i--) {
                tableModel.removeRow(i);
            }
        }
        try {
            ResultSet rs = stmt.executeQuery("SELECT * FROM patron");
            while (rs.next()) {
                tableModel.addRow(new Object[] {
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("dob"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        rs.getString("patronType")
                });
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        patronTbl.setDefaultEditor(Object.class, null);

        return patronTbl;
    }
    public void display() {
        int x = (int) parentGUI.getLocation().getX() + 100;
        int y = (int) parentGUI.getLocation().getY() + 100;
        gui.setLocation(x, y);
        gui.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
