package a2_2101040039.GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;

public class LibraryMenu extends WindowAdapter implements ActionListener {
    private Statement stmt = null;
    private Connection connection = null;
    private JFrame gui;
    private NewPatronWindow newPatronWindow;
    private NewBookWindow newBookWindow;
    private ListPatronWindow listPatronWindow;
    private ListBookWindow listBookWindow;
    private CheckoutBookWindow checkoutBookWindow;
    private ReturnBookWindow returnBookWindow;
    private ListTransactionWindow listTransactionWindow;

    public LibraryMenu() {
        setConnection();
        createGUI();
    }

    private void setConnection() {
        try {
            connection = DriverManager.getConnection(
                    "jdbc:sqlite:library.db");
            stmt = connection.createStatement();
            System.out.println("Connected to database!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void createGUI() {
        gui = new JFrame("Library Management System");
        gui.setSize(900, 800);
        gui.addWindowListener(this);
        JMenuBar menu = new JMenuBar();
        //file menu
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(this);
        fileMenu.add(exitItem);
        //patron menu
        JMenu patronMenu = new JMenu("Patron");
        JMenuItem newPatronItem = new JMenuItem("New Patron");
        JMenuItem listPatronItem = new JMenuItem("List Patron");
        newPatronItem.addActionListener(this);
        listPatronItem.addActionListener(this);
        patronMenu.add(newPatronItem);
        patronMenu.add(listPatronItem);
        //book menu
        JMenu bookMenu = new JMenu("Book");
        JMenuItem newBookItem = new JMenuItem("New Book");
        JMenuItem listBookItem = new JMenuItem("List Book");
        newBookItem.addActionListener(this);
        listBookItem.addActionListener(this);
        bookMenu.add(newBookItem);
        bookMenu.add(listBookItem);
        //transaction menu
        JMenu transactionMenu = new JMenu("Transaction");
        JMenuItem checkoutItem = new JMenuItem("Checkout Book");
        JMenuItem transRepItem = new JMenuItem("Transaction Report");
        JMenuItem returnBookItem = new JMenuItem("Return Book");
        checkoutItem.addActionListener(this);
        transRepItem.addActionListener(this);
        returnBookItem.addActionListener(this);
        transactionMenu.add(checkoutItem);
        transactionMenu.add(transRepItem);
        transactionMenu.add(returnBookItem);
        //add menu to menu bar
        menu.add(fileMenu);
        menu.add(patronMenu);
        menu.add(bookMenu);
        menu.add(transactionMenu);
        gui.setJMenuBar(menu);
        JPanel jPanel = new JPanel(new FlowLayout());
        jPanel.add(new JLabel("Return book will delete transaction from table. Please advance with caution."));
        gui.add(jPanel);
        gui.setLocationRelativeTo(null);
    }
    public void display() {
        gui.setVisible(true);
    }
    @Override
    public void windowClosing(WindowEvent e) {
        shutDown();
    }


    private void shutDown() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
        System.exit(0);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if(command.equals("Exit")) {
            shutDown();
        }
        else if(command.equals("New Patron")) {
            if (newPatronWindow == null) {
                newPatronWindow = new NewPatronWindow(gui, stmt);
            }
            newPatronWindow.display();
        }
        else if(command.equals("New Book")) {
            if (newBookWindow == null) {
                newBookWindow = new NewBookWindow(gui,  stmt);
            }
            newBookWindow.display();
        }
        else if(command.equals("List Patron")) {
            if (listPatronWindow == null) {
                listPatronWindow = new ListPatronWindow(gui,  stmt);
            }
            listPatronWindow.display();
        } else if (command.equals("List Book")) {
            if (listBookWindow == null) {
                listBookWindow = new ListBookWindow(gui,  stmt);
            }
            listBookWindow.display();
        } else if (command.equals("Checkout Book")) {
            if (checkoutBookWindow == null) {
                checkoutBookWindow = new CheckoutBookWindow(gui, stmt);
            }
            checkoutBookWindow.display();
        } else if (command.equals("Transaction Report")) {
            if (listTransactionWindow == null) {
                listTransactionWindow = new ListTransactionWindow(gui, stmt);
            }
            listTransactionWindow.display();
        } else if (command.equals("Return Book")) {
            if (returnBookWindow == null) {
                returnBookWindow = new ReturnBookWindow(gui, stmt);
            }
            returnBookWindow.display();
        }
    }
}
