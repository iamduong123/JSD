package a2_2101040039.GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ListTransactionWindow extends WindowAdapter implements ActionListener {
    private JFrame gui;
    private JFrame parentGUI;
    private DefaultTableModel tableModel;
    private JTable transactionTbl;
    private Statement stmt;
    private JComboBox<String> transactionOption;
    public ListTransactionWindow(JFrame parentGUI, Statement stmt) {
        this.parentGUI = parentGUI;
        this.stmt = stmt;
        createGUI();
    }
    private void createGUI() {
        gui = new JFrame("Transaction List");
        gui.addWindowListener(this);
        JPanel panel = new JPanel();
        panel.add(new JLabel("Option: "));
        String[] options = {"All transactions", "All checked-out books", "Overdue books"};
        transactionOption = new JComboBox<>(options);
        panel.add(transactionOption);
        transactionOption.setSelectedIndex(-1);
        JButton getReport = new JButton("Get Report");
        getReport.addActionListener(this);
        panel.add(getReport);
        gui.add(panel, BorderLayout.NORTH);
        gui.setSize(900,600);
        String[] headers = {"ID", "Book ISBN", "Book Title","Patron ID", "Patron name",  "Checkout Date", "Due Date"};
        Object[][] data = new Object[0][7];
        tableModel = new DefaultTableModel(data, headers);
        transactionTbl = new JTable(tableModel);
        transactionTbl.getColumnModel().getColumn(0).setPreferredWidth(200);
        transactionTbl.getColumnModel().getColumn(1).setPreferredWidth(300);
        transactionTbl.getColumnModel().getColumn(2).setPreferredWidth(600);
        transactionTbl.getColumnModel().getColumn(3).setPreferredWidth(200);
        transactionTbl.getColumnModel().getColumn(4).setPreferredWidth(600);
        transactionTbl.getColumnModel().getColumn(5).setPreferredWidth(400);
        transactionTbl.getColumnModel().getColumn(6).setPreferredWidth(400);
        gui.add(new JScrollPane(transactionTbl));


    }
    private void reloadAllTable(DefaultTableModel tableModel) {
        try {
            ResultSet rs = stmt.executeQuery("select [transaction].id, book.isbn, book.title, [transaction].patron_id, " +
                    "patron.name, [transaction].checkoutDate, [transaction].dueDate from [transaction] " +
                    "join patron on [transaction].patron_id = patron.id join book on [transaction].book_id = book.id");
            while (rs.next()) {
                tableModel.addRow(new Object[] {
                        rs.getInt("id"),
                        rs.getString("isbn"),
                        rs.getString("title"),
                        rs.getInt("patron_id"),
                        rs.getString("name"),
                        rs.getString("checkoutDate"),
                        rs.getString("dueDate")
                });
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    private void reloadCheckoutTable(DefaultTableModel tableModel) {
        try {
            ResultSet rs = stmt.executeQuery("select [transaction].id, book.isbn, book.title, [transaction].patron_id, patron.name, [transaction].checkoutDate, [transaction].dueDate\n" +
                    "from [transaction] join patron on [transaction].patron_id = patron.id\n" +
                    "join book on [transaction].book_id = book.id where(select date(substr(dueDate, 7, 4) || '-' || substr(dueDate, 4, 2) || '-' || substr(dueDate, 1, 2))) >= CURRENT_DATE");
            while (rs.next()) {
                tableModel.addRow(new Object[] {
                        rs.getInt("id"),
                        rs.getString("isbn"),
                        rs.getString("title"),
                        rs.getInt("patron_id"),
                        rs.getString("name"),
                        rs.getString("checkoutDate"),
                        rs.getString("dueDate")
                });
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    private void reloadOverdueTable(DefaultTableModel tableModel) {
        try {
            ResultSet rs = stmt.executeQuery("select [transaction].id, book.isbn, book.title, [transaction].patron_id, patron.name, [transaction].checkoutDate, [transaction].dueDate\n" +
                    "from [transaction] join patron on [transaction].patron_id = patron.id\n" +
                    "join book on [transaction].book_id = book.id where(select date(substr(dueDate, 7, 4) || '-' || substr(dueDate, 4, 2) || '-' || substr(dueDate, 1, 2))) < CURRENT_DATE");
            while (rs.next()) {
                tableModel.addRow(new Object[] {
                        rs.getInt("id"),
                        rs.getString("isbn"),
                        rs.getString("title"),
                        rs.getInt("patron_id"),
                        rs.getString("name"),
                        rs.getString("checkoutDate"),
                        rs.getString("dueDate")
                });
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    public void display() {
        int x = (int) parentGUI.getLocation().getX() + 100;
        int y = (int) parentGUI.getLocation().getY() + 100;
        gui.setLocation(x, y);
        gui.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        DefaultTableModel defaultTableModel = (DefaultTableModel) transactionTbl.getModel();
        defaultTableModel.setRowCount(0);
        if (command.equals("Get Report")) {
            String mode = transactionOption.getSelectedItem().toString();
            if (mode.equals("All transactions")) {
                reloadAllTable(defaultTableModel);
            }else if (mode.equals("All checked-out books")) {
                reloadCheckoutTable(defaultTableModel);
            } else if (mode.equals("Overdue books")) {
                reloadOverdueTable(defaultTableModel);
            }
        }
    }
}
