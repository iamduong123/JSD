package a2_2101040039.GUI;

import a2_2101040039.common.PatronType;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Objects;

public class NewPatronWindow extends WindowAdapter implements ActionListener {
    private JFrame gui;
    private JFrame parentGUI;
    private JTextField inputName;
    private JTextField inputDOB;
    private JTextField inputEmail;
    private JTextField inputPhoneNum;
    private JComboBox inputPaType;
    private Statement stmt;

    public NewPatronWindow(JFrame parentGUI, Statement stmt) {
        this.parentGUI = parentGUI;
        this.stmt = stmt;
        createGUI();
    }

    private void createGUI() {
        gui = new JFrame("New Patron");
        gui.addWindowListener(this);

        //create
        JPanel panel = new JPanel(new GridLayout(5, 2, 5, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 10, 20));
        //name
        panel.add(new JLabel("Name"));
        inputName = new JTextField(15);
        panel.add(inputName);

        //dob
        panel.add(new JLabel("Date of Birth (DD/MM/YYYY)"));
        inputDOB = new JTextField(15);
        panel.add(inputDOB);

        //email
        panel.add(new JLabel("Email"));
        inputEmail = new JTextField(15);
        panel.add(inputEmail);

        //phone
        panel.add(new JLabel("Phone"));
        inputPhoneNum = new JTextField(15);
        panel.add(inputPhoneNum);

        //patron type
        panel.add(new JLabel("Patron Type"));
        inputPaType = new JComboBox(PatronType.values());
        panel.add(inputPaType);

        //bottom panel
        JPanel bottomPanel = new JPanel();
        JButton btnAddPatron = new JButton("Add");
        btnAddPatron.addActionListener(this);
        bottomPanel.add(btnAddPatron);
        JButton btnCancel = new JButton("Cancel");
        btnCancel.addActionListener(this);
        bottomPanel.add(btnCancel);
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        gui.add(bottomPanel, BorderLayout.SOUTH);
        gui.add(panel);
        gui.pack();
        int x = (int) parentGUI.getLocation().getX() + 100;
        int y = (int) parentGUI.getLocation().getY() + 100;
        gui.setLocation(x, y);

    }

    public void display() {
        gui.setVisible(true);
        System.out.println("Add Patron GUI");
    }

    @Override
    public void windowClosing(WindowEvent e) {
        disposeGUI();
    }

    private void disposeGUI() {
        inputName.setText("");
        inputPhoneNum.setText("");
        inputEmail.setText("");
        inputDOB.setText("");
        inputPaType.setSelectedIndex(0);
        gui.dispose();
        System.out.println("Add Patron GUI disposed...");
    }
    public void addPatron(String name, String dob, String email, String phone, String patronType) {
        try {
            stmt.execute("INSERT INTO patron (name, dob, email, phone, patronType) VALUES ('"+ name + "', '" + dob + "', '" + email + "', '" + phone + "', '" + patronType + "')");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if (command.equals("Cancel")) {
            disposeGUI();
        } else if (command.equals("Add")) {
            addPatron(inputName.getText(), inputDOB.getText(), inputEmail.getText(), inputPhoneNum.getText(), Objects.requireNonNull(inputPaType.getSelectedItem()).toString());
            disposeGUI();
        }
    }
}
