package a2_2101040039.GUI;

import a2_2101040039.Book;
import a2_2101040039.common.Genre;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Objects;

public class NewBookWindow extends WindowAdapter implements ActionListener {
    private JFrame gui;
    private JFrame parentGUI;
    private JTextField inputTitle;
    private JTextField inputAuthor;
    private JTextField inputYear;
    private JTextField inputNumOfCopies;
    private JComboBox inputGenre;
    private Statement stmt;
    public NewBookWindow(JFrame parentGUI, Statement stmt) {
        this.parentGUI = parentGUI;
        this.stmt = stmt;
        createGUI();
    }
    private void createGUI() {

        gui = new JFrame("New Book");
        gui.addWindowListener(this);
        JPanel panel = new JPanel(new GridLayout(5,2,5,10));
        panel.setBorder(BorderFactory.createEmptyBorder(15,20,10,20));

        panel.add(new JLabel("Title"));
        inputTitle = new JTextField(15);
        panel.add(inputTitle);

        panel.add(new JLabel("Author"));
        inputAuthor = new JTextField(15);
        panel.add(inputAuthor);

        panel.add(new JLabel("Genre"));
        inputGenre = new JComboBox(Genre.values());
        panel.add(inputGenre);

        panel.add(new JLabel("Year"));
        inputYear = new JTextField(15);
        panel.add(inputYear);

        panel.add(new JLabel("Number of Copies Available"));
        inputNumOfCopies = new JTextField(15);
        panel.add(inputNumOfCopies);
        JPanel bottomPanel = new JPanel();
        JButton btnAddPatron = new JButton("Add");
        btnAddPatron.addActionListener(this);
        bottomPanel.add(btnAddPatron);
        JButton btnCancel = new JButton("Cancel");
        btnCancel.addActionListener(this);
        bottomPanel.add(btnCancel);
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(0,0,10,0));

        gui.add(bottomPanel, BorderLayout.SOUTH);
        gui.add(panel);
        gui.pack();
        int x = (int) parentGUI.getLocation().getX() + 100;
        int y = (int) parentGUI.getLocation().getY() + 100;
        gui.setLocation(x, y);
    }
    public void display() {
        gui.setVisible(true);
    }
    @Override
    public void windowClosing(WindowEvent e) {
        disposeGUI();
    }

    private void disposeGUI() {
        inputTitle.setText("");
        inputAuthor.setText("");
        inputYear.setText("");
        inputNumOfCopies.setText("");
        inputGenre.setSelectedIndex(0);
        gui.dispose();
        System.out.println("Add Book GUI disposed...");
    }
    public void addBook(String title, String author, String genre, int pubYear, int numCopiesAvailable) {
        Book book = new Book(title, author, Genre.valueOf(genre.toUpperCase()), pubYear, numCopiesAvailable);
        try {
            stmt.execute("INSERT INTO book (ISBN, title, author, genre, pubYear, numCopiesAvailable) VALUES ('"+ book.getISBN() + "', '" + book.getTitle() + "', '" + book.getAuthor() + "', '" + book.getGenre() + "', '" + book.getYear() + "', '" + book.getNumCopiesAvailable()+"')");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if (command.equals("Cancel")) {
            disposeGUI();
        } else if (command.equals("Add")) {
            addBook(inputTitle.getText(), inputAuthor.getText(), Objects.requireNonNull(inputGenre.getSelectedItem()).toString(), Integer.parseInt(inputYear.getText()), Integer.parseInt(inputNumOfCopies.getText()));
            disposeGUI();
        }
    }
}
