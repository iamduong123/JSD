package a2_2101040039.GUI;

import a2_2101040039.Patron;
import a2_2101040039.common.PatronType;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Objects;

public class CheckoutBookWindow extends WindowAdapter implements ActionListener {
    private Connection connection;
    private Statement stmt;
    private JFrame gui;
    private JFrame parentGUI;
    private LibraryMenu libraryMenu;
    private JLabel checkoutDateLabel;
    private JTextField inputDueDate;
    private JComboBox inputPatron;
    private JComboBox inputBook;
    ArrayList<Patron> patrons = new ArrayList<>();
    ArrayList<String> books = new ArrayList<>();

    public CheckoutBookWindow(JFrame parentGUI, Statement stmt) {
        this.parentGUI = parentGUI;
        this.stmt = stmt;
        createGUI();
    }

    private void createGUI() {
        try {
            ResultSet rs = stmt.executeQuery("SELECT title FROM book WHERE numCopiesAvailable > 0");
            while (rs.next()) {
                books.add(rs.getString(1));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        gui = new JFrame("Checkout Book");
        gui.addWindowListener(this);
        JPanel panel = new JPanel(new GridLayout(4, 2, 5, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 10, 20));

        panel.add(new JLabel("Patron"));
        inputPatron = new JComboBox(getPatron().toArray());
        panel.add(inputPatron);
        inputPatron.setSelectedIndex(-1);

        panel.add(new JLabel("Book"));
        inputBook = new JComboBox(books.toArray());
        panel.add(inputBook);
        inputBook.setSelectedIndex(-1)
        ;
        panel.add(new JLabel("Checkout Date"));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String checkoutDate = java.time.LocalDate.now().format(formatter);
        checkoutDateLabel = new JLabel(checkoutDate);
        panel.add(checkoutDateLabel);

        panel.add(new JLabel("Due Date (DD/MM/YYYY)"));
        inputDueDate = new JTextField(15);
        panel.add(inputDueDate);

        JPanel bottomPanel = new JPanel();
        JButton btnCheckout = new JButton("Checkout");
        btnCheckout.addActionListener(this);
        bottomPanel.add(btnCheckout);
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        gui.add(bottomPanel, BorderLayout.SOUTH);
        gui.add(panel);
        gui.pack();

    }

    public void display() {
        int x = (int) parentGUI.getLocation().getX() + 100;
        int y = (int) parentGUI.getLocation().getY() + 100;
        gui.setLocation(x, y);
        gui.setVisible(true);
    }

    public ArrayList<Patron> getPatron() {
        try {
            ResultSet rs = stmt.executeQuery("SELECT * FROM patron");
            while (rs.next()) {
                Patron patron = new Patron(rs.getString("name"),
                        new SimpleDateFormat("dd/MM/yyyy").parse(rs.getString("dob")),
                        rs.getString("email"),
                        rs.getString("phone"),
                        PatronType.valueOf(rs.getString("patronType")),
                        rs.getInt("id"));
                patrons.add(patron);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return patrons;
    }

    public int getPatronID() {
        String[] patron = Objects.requireNonNull(inputPatron.getSelectedItem()).toString().split("\\s+");
        return Integer.parseInt(patron[patron.length - 1].replaceAll("\\D", "").replaceAll("^0+(?!$)", ""));
    }
    public int getBookID() {
        int bookID = 0;
        try {

            ResultSet rs = stmt.executeQuery("SELECT id FROM book WHERE title = '" + Objects.requireNonNull(inputBook.getSelectedItem()).toString() + "'");
            bookID = rs.getInt("id");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return bookID;
    }

    public int getPatronTransaction(int patronID) {
        ResultSet rs = null;
        int numOfTrans = 0;
        try {

            rs = stmt.executeQuery("SELECT COUNT(*) as numOfTrans FROM [transaction] WHERE patron_id =" + patronID);
            numOfTrans = rs.getInt("numOfTrans");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return numOfTrans;
    }

    public String getPatronType(int patronID) {
        ResultSet rs = null;
        String patronType = null;
        try {

            rs = stmt.executeQuery("SELECT * FROM patron WHERE id =" + patronID);
            patronType = rs.getString("patronType");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return patronType;
    }
    public void decreaseNumOfBooks(int bookID) {
        try {
            stmt.execute("update book set numCopiesAvailable = numCopiesAvailable - 1 where id =" + bookID);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }


    public void addTransaction() {
        int id = getPatronID();
        if (getPatronType(id).equals("REGULAR")) {
            if (getPatronTransaction(id) == 3) {
                JFrame frame = new JFrame("Error");
                JOptionPane.showMessageDialog(frame, "Patron has exceed the number of checkout books");
                gui.add(frame);
            } else {
                try {
                    stmt.execute("INSERT INTO [transaction] (book_id, patron_id, checkoutDate, dueDate) VALUES ('" + getBookID() + "', '" + getPatronID() + "', '" + checkoutDateLabel.getText() + "', '" + inputDueDate.getText() + "')");
                    decreaseNumOfBooks(getBookID());
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                }
            }
        } else {
            if(getPatronTransaction(id) == 5) {
                JFrame frame = new JFrame("Error");
                JOptionPane.showMessageDialog(frame, "Patron has exceed the number of checkout books", "Error", JOptionPane.ERROR_MESSAGE);
                gui.add(frame);
            }
            else {
                try {
                    stmt.execute("INSERT INTO [transaction] (book_id, patron_id, checkoutDate, dueDate) VALUES ('" + getBookID() + "', '" + getPatronID() + "', '" + checkoutDateLabel.getText() + "', '" + inputDueDate.getText() + "')");
                    decreaseNumOfBooks(getBookID());
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                }
            }
        }
    }
    private void disposeGUI() {
        inputPatron.setSelectedIndex(-1);
        inputBook.setSelectedIndex(-1);
        inputDueDate.setText("");
        gui.dispose();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if (command.equals("Checkout")) {
            if (inputDueDate.getText().isEmpty()) {
                JFrame frame = new JFrame("Error");
                JOptionPane.showMessageDialog(frame,
                        "Missing input data",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            } else {
                int result = JOptionPane.showConfirmDialog(gui, "Do you want to save this checkout transaction",
                        "Confirm transaction", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (result == JOptionPane.YES_OPTION) {
                    addTransaction();
                    disposeGUI();
                }
            }
        }
    }
}
