package a2_2101040039.GUI;

import a2_2101040039.Book;
import a2_2101040039.LibraryTransaction;
import a2_2101040039.Patron;
import a2_2101040039.common.Genre;
import a2_2101040039.common.PatronType;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

public class ReturnBookWindow extends WindowAdapter implements ActionListener {
    private JFrame gui;
    private JFrame parentGUI;
    private Statement stmt;
    private JComboBox<Patron> patronCB;
    private JComboBox bookCB;
    private JTextField returnDate;
    private ArrayList<Patron> patrons = new ArrayList<>();
    private ArrayList<String> books = new ArrayList<>();
    String[] names;
    private int patronID;

    public ReturnBookWindow(JFrame parentGUI, Statement stmt) {
        this.parentGUI = parentGUI;
        this.stmt = stmt;
        createGUI();
    }

    private void createGUI() {
        gui = new JFrame("Return Book");
        gui.addWindowListener(this);
        JPanel panel = new JPanel(new GridLayout(3, 2, 5, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 10, 20));
        panel.add(new JLabel("Patron"));
        patronCB = new JComboBox(getPatron().toArray());
        patronCB.addItemListener(e -> {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                patronID = getPatronID();
                books.clear();
                bookCB.removeAllItems();
                names = new String[]{};
                names = getNotReturnedBook(patronID).toArray(new String[0]);
                for (String name : names) {
                    bookCB.addItem(name);
                }
            } else if (e.getStateChange() == ItemEvent.DESELECTED) {
                bookCB.removeAllItems();
                names = null;

            }
        });
        panel.add(patronCB);
        panel.add(new JLabel("Book"));
        bookCB = new JComboBox<>();
        panel.add(bookCB);


        panel.add(new JLabel("Return Date (DD/MM/YYYY)"));
        returnDate = new JTextField(15);
        panel.add(returnDate);

        JPanel bottomPanel = new JPanel();
        JButton btnReturnBook = new JButton("Return");
        btnReturnBook.addActionListener(this);
        bottomPanel.add(btnReturnBook);
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        gui.add(bottomPanel, BorderLayout.SOUTH);
        gui.add(panel);
        gui.pack();
    }

    public void display() {
        patronCB.setSelectedIndex(-1);
        int x = (int) parentGUI.getLocation().getX() + 100;
        int y = (int) parentGUI.getLocation().getY() + 100;
        gui.setLocation(x, y);
        gui.setVisible(true);
    }

    public ArrayList<String> getNotReturnedBook(int patronID) {
        try {
            ResultSet rs = stmt.executeQuery("SELECT title FROM book inner join [transaction] on book.id = [transaction].book_id where patron_id =" + patronID);
            while (rs.next()) {
                books.add(rs.getString(1));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return books;
    }

    public int getBookID() {
        int bookID = 0;
        try {

            ResultSet rs = stmt.executeQuery("SELECT id FROM book WHERE title = '" + Objects.requireNonNull(bookCB.getSelectedItem()).toString() + "'");
            bookID = rs.getInt("id");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return bookID;
    }

    public ArrayList<Patron> getPatron() {
        try {
            ResultSet rs = stmt.executeQuery("SELECT * FROM patron");
            while (rs.next()) {
                Patron patron = new Patron(rs.getString("name"),
                        new SimpleDateFormat("dd/MM/yyyy").parse(rs.getString("dob")),
                        rs.getString("email"),
                        rs.getString("phone"),
                        PatronType.valueOf(rs.getString("patronType")),
                        rs.getInt("id"));
                patrons.add(patron);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return patrons;
    }

    public int getPatronID() {
        String[] patron = Objects.requireNonNull(patronCB.getSelectedItem()).toString().split("\\s+");
        patronID = Integer.parseInt(patron[patron.length - 1].replaceAll("\\D", "").replaceAll("^0+(?!$)", ""));
        return patronID;
    }

    public void increaseNumOfBooks(int bookID) {
        try {
            stmt.execute("update book set numCopiesAvailable = numCopiesAvailable + 1 where id =" + bookID);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getTransactionID() {
        int transactionID = 0;
        try {
            ResultSet rs = stmt.executeQuery("select id from [transaction] where book_id = " + getBookID() + " and patron_id=" + getPatronID());
            transactionID = rs.getInt("id");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return transactionID;
    }

    public void returnBook() {
        try {
            if (calculateFee() > 0) {
                JFrame frame = new JFrame("Late Return");
                JOptionPane.showMessageDialog(frame,
                        "Your late fee is $" + calculateFee(),
                        "Late Return",
                        JOptionPane.INFORMATION_MESSAGE);
            }
            stmt.execute("delete from [transaction] where id =" + getTransactionID());
            increaseNumOfBooks(getBookID());
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void disposeGUI() {
        patronCB.setSelectedIndex(-1);
        bookCB.setSelectedIndex(-1);
        returnDate.setText("");
        gui.dispose();
    }

    private Patron createPatron() {
        Patron patron = null;
        try {
            ResultSet rs = stmt.executeQuery("SELECT * from patron where id = " + getPatronID());
            patron = new Patron(rs.getString("name"), new SimpleDateFormat("dd/MM/yyyy").parse(rs.getString("dob")),
                    rs.getString("email"), rs.getString("phone"), PatronType.valueOf(rs.getString("patronType")),
                    getPatronID());
        } catch (SQLException e) {
            e.getMessage();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return patron;
    }

    private Book createBook() {
        Book book = null;
        try {
            ResultSet rs = stmt.executeQuery("select * from book where id = " + getBookID());
            book = new Book(rs.getString("title"), rs.getString("author"),
                    Genre.valueOf(rs.getString("genre")), rs.getInt("pubYear"),
                    rs.getInt("numCopiesAvailable"));
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return book;
    }
    private LibraryTransaction createTransaction() {
        LibraryTransaction transaction = null;
        try {
            ResultSet rs = stmt.executeQuery("SELECT * from [transaction] where id = " + getTransactionID());
            Date checkoutDate = new SimpleDateFormat("dd/MM/yyyy").parse(rs.getString("checkoutDate"));
            Date dueDate = new SimpleDateFormat("dd/MM/yyyy").parse(rs.getString("dueDate"));
            transaction = new LibraryTransaction(createPatron(), createBook(),
                    checkoutDate, dueDate);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return transaction;
    }

    private double calculateFee() {
        LibraryTransaction transaction = createTransaction();
        try {
            transaction.setReturnDate(new SimpleDateFormat("dd/MM/yyyy").parse(returnDate.getText()));
        } catch (ParseException e) {
            System.out.println(e.getMessage());
        }
        return transaction.calculateFine(transaction.getReturnDate());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if (command.equals("Return")) {
            if (returnDate.getText().isEmpty()) {
                JFrame frame = new JFrame("Error");
                JOptionPane.showMessageDialog(frame,
                        "Missing input data",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            } else {
                returnBook();
                disposeGUI();
            }
        }
    }
}
