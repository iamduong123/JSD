package a2_2101040039.GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.sql.*;
import java.util.ArrayList;

public class ListBookWindow extends WindowAdapter implements ActionListener {
    private JFrame gui;
    private JFrame parentGUI;
    private ArrayList<Integer> ids;
    private JTable bookTbl;
    private Statement stmt;


    public ListBookWindow(JFrame parentGUI, Statement stmt) {
        this.parentGUI = parentGUI;
        this.stmt = stmt;
        createGUI(reloadTable());
    }

    private void createGUI(JTable patronTbl) {
        gui = new JFrame("Book List");
        gui.addWindowListener(this);
        JScrollPane scrPatron = new JScrollPane(patronTbl);
        gui.add(scrPatron);
    }
    private JTable reloadTable() {
        DefaultTableModel tableModel = null;
        ids = new ArrayList<>();
        if(bookTbl == null) {
            String[] headers = {"ID", "ISBN", "Title", "Author", "Genre", "Publication Year", "Number of Copies Available"};
            Object[][] data = new Object[0][7];
            tableModel = new DefaultTableModel(data, headers);
            bookTbl = new JTable(tableModel);
            bookTbl.getColumnModel().getColumn(0).setPreferredWidth(20);
            bookTbl.getColumnModel().getColumn(1).setPreferredWidth(200);
            bookTbl.getColumnModel().getColumn(2).setPreferredWidth(300);
            bookTbl.getColumnModel().getColumn(3).setPreferredWidth(200);
            bookTbl.getColumnModel().getColumn(4).setPreferredWidth(200);
            bookTbl.getColumnModel().getColumn(5).setPreferredWidth(100);
            bookTbl.getColumnModel().getColumn(6).setPreferredWidth(200);

        } else {
            tableModel = (DefaultTableModel) bookTbl.getModel();
            for (int i = tableModel.getRowCount()-1; i >=0; i--) {
                tableModel.removeRow(i);
            }
        }
        try {
            ResultSet rs = stmt.executeQuery("SELECT * FROM book");
            while (rs.next()) {
                tableModel.addRow(new Object[] {
                        rs.getInt("id"),
                        rs.getString("isbn"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("genre"),
                        rs.getInt("pubYear"),
                        rs.getInt("numCopiesAvailable")
                });
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        bookTbl.setDefaultEditor(Object.class, null);

        return bookTbl;
    }
    public void display() {
        int x = (int) parentGUI.getLocation().getX() + 100;
        int y = (int) parentGUI.getLocation().getY() + 100;
        gui.setLocation(x, y);
        gui.setVisible(true);
        gui.pack();
    }


    @Override
    public void actionPerformed(ActionEvent e) {

    }
}

