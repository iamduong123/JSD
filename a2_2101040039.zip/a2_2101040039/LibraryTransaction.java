package a2_2101040039;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class LibraryTransaction implements Comparable<LibraryTransaction> {
    private Patron patron;
    private Book book;
    private Date checkOutDate;
    private Date dueDate;
    private Date returnDate;
    private double fine;

    public LibraryTransaction(Patron patron, Book book, Date checkOutDate, Date dueDate) {
        this.patron = patron;
        this.book = book;
        this.checkOutDate = checkOutDate;
        this.dueDate = dueDate;
    }

    public Patron getPatron() {
        return patron;
    }

    public Book getBook() {
        return book;
    }

    public Date getCheckOutDate() {
        return checkOutDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public double getFine() {
        return fine;
    }

    public long calculateTimeDiff(Date returnDate) {
        return TimeUnit.DAYS.convert((returnDate.getTime() - getDueDate().getTime()), TimeUnit.MILLISECONDS);

    }
// checkoutDate is later than đueDate
    public void setReturnDate(Date date) {
        this.returnDate = date;
    }

    public double calculateFine(Date returnDate) {
        double fineCalc = 0;
        long timeDiff = calculateTimeDiff(returnDate);
        if (timeDiff <= 7 && timeDiff >= 1) {
            fineCalc = (double) timeDiff;
        } else if (timeDiff >= 8 && timeDiff <= 14) {
            fineCalc = timeDiff * 2;
        } else if (timeDiff > 14) {
            fineCalc = timeDiff * 3;
        }
        return fineCalc;
    }

    public void setFine(double calculatedFine) {
        this.fine = calculatedFine;
    }

    public String getDescription() {
        Format dateFormat = new SimpleDateFormat("EEE, MMM dd yyyy");
        List<String> content = new ArrayList<>();
        content.add("Patron ID: " + getPatron().getId());
        content.add("Book ISBN: " + getBook().getISBN());
        content.add("Checkout Date: " + dateFormat.format(getCheckOutDate()));
        content.add("Due Date: " + dateFormat.format(getDueDate()));
        if (getReturnDate() != null) {

            content.add("Return Date: " + dateFormat.format(getReturnDate()));
        }
        if (getFine() > 0) {
            content.add("Fine Amount: $" + String.format("%.2f", getFine()));
        }
        StringBuilder description = new StringBuilder("Transaction Details:" + "\n");
        for (String line : content) {
            StringBuilder stbLine = new StringBuilder(line);
            stbLine.append("\n");
            for (int i = 0; i < 4; i++) {
                stbLine.insert(0, " ");
            }
            description.append(stbLine);
        }
        return description.toString();
    }
    @Override
    public String toString() {
        return getDescription();
    }
    @Override
    public int compareTo(LibraryTransaction o) {
        return Integer.compare(this.getPatron().getIdNumber(), o.getPatron().getIdNumber());
    }
}
