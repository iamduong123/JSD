package a2_2101040039;

import a2_2101040039.common.DateUtils;

import java.util.*;

public class LibraryManager {
    private List<Book> books = new ArrayList<>();
    private List<LibraryTransaction> transactions = new ArrayList<>();
    private Patron patron;

    public List<LibraryTransaction> getTransactions() {
        return transactions;
    }

    public String getCheckedoutList() {
        StringBuilder stb = new StringBuilder();
        for (LibraryTransaction trans : getTransactions()) {
            if (trans.getReturnDate() == null) {
                stb.append("\n").append(trans.getDescription());
            }
        }
        return stb.toString();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public List<LibraryTransaction> getCheckedOutBooks(Patron patron) {
        this.patron = patron;
        List<LibraryTransaction> patronTransactions = new ArrayList<>();
        for (LibraryTransaction transaction : getTransactions()) {
            if (transaction.getPatron().getId().equalsIgnoreCase(patron.getId())) {
                patronTransactions.add(transaction);
            }
        }

        return patronTransactions;
    }

    /*
    make it return boolean so i can print out error?
     */
    public LibraryTransaction checkoutBook(Patron patron, Book book, Date checkoutDate, Date dueDate) {
        int limit = 0;
        switch (patron.getPatronType()) {
            case REGULAR:
                limit = 3;
                break;
            case PREMIUM:
                limit = 5;
                break;
        }
        if (book.getNumCopiesAvailable() != 0) {
            if (getCheckedOutBooks(patron).size() < limit) {
                LibraryTransaction currentTransaction = new LibraryTransaction(patron, book, checkoutDate, dueDate);
                if (dueDate.getTime() - checkoutDate.getTime() < 0) {
                    System.out.println("Due date is sooner than checkout date.");
                    return null;
                } else {
                    book.setNumCopiesAvailable(book.getNumCopiesAvailable() - 1);
                    transactions.add(currentTransaction);
                    return currentTransaction;
                }
            } else {
                System.out.println("You have exceeded your books limit.");
                return null;
            }
        } else {
            System.out.println("No book available.");
            return null;
        }
    }


    public void returnBook(LibraryTransaction transaction, Date returnDate) { //need to use returndate
        // update copies
        transaction.getBook().setNumCopiesAvailable(transaction.getBook().getNumCopiesAvailable() + 1);

        //calculate fine
        if (transaction.calculateTimeDiff(returnDate) > 0) {
            transaction.setFine(transaction.calculateFine(returnDate));
        }
        transactions.remove(transaction);
        System.out.println("Return book successfully");
    }

    public List<LibraryTransaction> getOverdueBooks() {
        List<LibraryTransaction> overdueBooks = new ArrayList<>();
        for (LibraryTransaction transaction : transactions) {
            if (transaction.calculateTimeDiff(new DateUtils().getCurrentDate()) > 0 && transaction.getReturnDate() == null) {
                overdueBooks.add(transaction);
            }
        }
        return overdueBooks;
    }

    public String getOverdueBooksList() {
        StringBuilder stb = new StringBuilder();
        for (LibraryTransaction trans : getOverdueBooks()) {
            stb.append("\n").append(trans.getDescription());
        }
        return stb.toString();
    }

    public void sort() {
        Collections.sort(transactions);
    }

    public String getList() {
        List<LibraryTransaction> list = getCheckedOutBooks(patron);
        StringBuilder stb = new StringBuilder();
        for (LibraryTransaction trans : list) {
            stb.append(trans).append("\n");
        }
        return stb.toString();
    }

}