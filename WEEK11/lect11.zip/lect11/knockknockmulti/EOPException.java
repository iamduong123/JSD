package lect11.knockknockmulti;

/**
 * End-of-program exception is thrown to signal the end-of-game.
 */
public class EOPException extends Exception {
    public EOPException(String msg) {
        super(msg);
    }
}
